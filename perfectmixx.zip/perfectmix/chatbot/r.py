from flask import Flask, request, render_template

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("hello.html", savings=None, expenditures=None)

@app.route("/get_advice", methods=["POST"])
def get_advice():
    try:
        # Retrieve form data
        income = request.form.get('income')
        expenses = request.form.get('expenses')

        # Convert income to a float
        income = float(income)

        # Convert expenses to a list of floats
        expenses_list = [float(x.strip()) for x in expenses.split(',')]

        # Calculate total expenditures and savings
        total_expenditures = sum(expenses_list)
        savings = income - total_expenditures

        return render_template("hello.html", income=income, expenditures=total_expenditures, savings=savings)
    
    except ValueError as e:
        # Handle invalid input (e.g., non-numeric input)
        return f"Invalid input: {str(e)}"

    except Exception as e:
        # Handle other exceptions
        return f"An error occurred: {str(e)}"

if __name__ == "__main__":
    app.run(debug=True)
